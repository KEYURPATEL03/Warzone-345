#include "A.h"
#include "C.h"
#include <iostream>
using namespace std; 

int main(){
  cout << "Executing A.cpp's main function" << endl; 
  bgv = 1;
  cff();
  C co(2);
  co.cmf(bgv); 
  return(0);
}
