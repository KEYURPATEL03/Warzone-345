void cff();

struct C{
public:
  int cmv;
  C(int);
  void cmf(int);
};
