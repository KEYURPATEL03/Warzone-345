#include "B.h"
#include <iostream>

int main(){
  std::cout << "Executing B.cpp's main function" << std::endl; 
  return(0);
}
