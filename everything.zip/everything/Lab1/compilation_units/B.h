int bgv;
