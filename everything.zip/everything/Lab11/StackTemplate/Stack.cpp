//constructor with the default size 10
#include "Stack.h"

template <typename T>
Stack<T>::Stack(int s)
{
	size = s > 0 && s < 1000 ? s : 10;
	top = -1;  // initialize stack
	stackPtr = new T[size];
}

// push an element onto the Stack 
template <typename T>
int Stack<T>::push(const T& item)
{
	if (!isFull())
	{
		stackPtr[++top] = item;
		return 1;  // push successful
	}
	return 0;  // push unsuccessful
}

// pop an element off the Stack
template <typename T>
int Stack<T>::pop(T& popValue)
{
	if (!isEmpty())
	{
		popValue = stackPtr[top--];
		return 1;  // pop successful
	}
	return 0;  // pop unsuccessful
}

// template operator that flushes the stack on an 
// output stream (not very intuitive though, as 
// outputting a stack also destroys it...)
template <typename T>
ostream& operator<<( ostream& output, Stack<T> stack)
{
	int i;
	while (stack.pop(i))
    output << i << ' ';
	return output;
}

// Explicit template instantiations
// this makes this compilation unit to generate
// some instances of these templates, which can
// then be linked by other compilation units
// 
// If we dont do that, then we need to have all 
// out template declarations moved to the header
// file. 
template class Stack<int>;
template class Stack<float>;
template ostream& operator<<(ostream&, Stack<int>);
