// StackDriver.cpp
// template instantiation

#include "Stack.h"
#include <iostream>
using namespace std;

void main() {
  Stack<float> fs(5);
  float f = 1.1;
  while (fs.push(f)) {
    cout << f << ' ';
    f += 1.1;
  }
  while (fs.pop(f))
    cout << f << ' ';
  Stack<int> is;
  int i = 1.1;
  while (is.push(i)) {
    cout << i << ' ';
    i += 1;
  }
  while (is.pop(i))
    cout << i << ' ';

  Stack<int> is2;
  int i2 = 1;
  while (is2.push(i2)) {
    cout << i2 << ' ';
    i2 += 1;
  }
  //use of the template operator
  cout << is2;

  int in; cin >> in;
} 
