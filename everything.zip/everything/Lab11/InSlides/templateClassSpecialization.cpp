// explicit_specialization1.cpp
// compile with: /EHsc
#include <iostream>
using namespace std;

// Template class declaration and definition
template <class T> class Formatter
{
    T* m_t;
public:
    Formatter(T* t) : m_t(t) { }
    void print()
    {
        cout << *m_t << endl;
    }
};

// Specialization of template class for type char*
template<> class Formatter<char*>
{
    char** m_t;
public:
    Formatter(char** t) : m_t(t) { }
    void print()
    {
        cout << "Char value: " << **m_t << endl;
    }
};

int main()
{
    int i = 157;
    // Use the generic template with int as the argument.
    Formatter<int> formatter1(&i);

    char str[10] = "string1";
    char* str1 = "tring2";
    // Use the specialized template.
    Formatter<char*> formatter2(&str1);

    formatter1.print(); // 157
    formatter2.print(); // Char value : s
	int in; cin >> in;
}

template <class T>
class X
{
    public:
	static T s ;
} ;

int main()
{
	X<int> xi ;
       X<char*> xc ;
}

template <class T>
class X
{
    public:
	static T s ;
} ;

template <class T> T X<T>::s = 0 ;
template <> int X<int>::s = 3 ;
template <> char* X<char*>::s = "Hello" ;

int main()
{
	X<int> xi ;
	cout << "xi.s = " << xi.s << endl ;

       X<char*> xc ;
	cout << "xc.s = " << xc.s << endl ;
	
	return 0 ;
}

template <class T>
void f(T t)
{
	static T s  = 0;
	s = t ;
	cout << "s = " << s << endl ;
} 

int main()
{
	f(10) ;
	f("Hello") ;
	
	return 0 ;
}

